/*
 * Copyright (c) 2013 Bryan O'Sullivan <bos@serpentine.com>.
 */

#ifndef _text_cbits_h
#define _text_cbits_h

#define UTF8_ACCEPT 0
#define UTF8_REJECT 12

#endif
